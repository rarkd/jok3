<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
requireAdminAuth();

// Handle token generation
$message = '';
$messageType = 'success'; // Definisikan variabel ini di awal
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['generate_token'])) {
    $token = generateToken();
    $tokenHash = password_hash($token, PASSWORD_DEFAULT);
    $customerName = !empty($_POST['customer_name']) ? $_POST['customer_name'] : 'Customer-' . substr($token, 0, 8);
    
    $stmt = $pdo->prepare("INSERT INTO tokens (token_hash, token_plain, customer_name) VALUES (?, ?, ?)");
    $stmt->execute([$tokenHash, $token, $customerName]);
    $message = 'New token generated for ' . $customerName . ': ' . $token;
}

// Handle token deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_token'])) {
    $tokenId = $_POST['token_id'];
    $stmt = $pdo->prepare("DELETE FROM tokens WHERE id = ?");
    $stmt->execute([$tokenId]);
    $message = 'Token deleted successfully';
    $messageType = 'success';
}

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $requestId = $_POST['request_id'];
    $status = $_POST['status'];
    
    $stmt = $pdo->prepare("UPDATE requests SET status = ? WHERE id = ?");
    $stmt->execute([$status, $requestId]);
    $message = 'Request status updated';
    $messageType = 'success';
}

// Handle result upload dengan preview link
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_result'])) {
    $requestId = $_POST['request_id'];
    $previewLink = !empty($_POST['preview_link']) ? $_POST['preview_link'] : null;
    
    if (isset($_FILES['result_file']) && $_FILES['result_file']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../uploads/results/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $fileName = uniqid() . '_' . basename($_FILES['result_file']['name']);
        $targetPath = $uploadDir . $fileName;
        
        if ($_FILES['result_file']['size'] > 50 * 1024 * 1024) {
            $message = 'File too large. Maximum size is 50MB.';
            $messageType = 'error';
        } else {
            if (move_uploaded_file($_FILES['result_file']['tmp_name'], $targetPath)) {
                // Save to database
                $stmt = $pdo->prepare("INSERT INTO results (request_id, result_file, preview_link) VALUES (?, ?, ?)");
                $stmt->execute([$requestId, 'uploads/results/' . $fileName, $previewLink]);
                
                // Update request status
                $stmt = $pdo->prepare("UPDATE requests SET status = 'Need Revision' WHERE id = ?");
                $stmt->execute([$requestId]);
                
                $message = 'Result uploaded successfully';
                $messageType = 'success';
            } else {
                $message = 'Failed to upload result file.';
                $messageType = 'error';
            }
        }
    } else if ($previewLink) {
        // Hanya preview link tanpa file
        $stmt = $pdo->prepare("INSERT INTO results (request_id, preview_link) VALUES (?, ?)");
        $stmt->execute([$requestId, $previewLink]);
        
        // Update request status
        $stmt = $pdo->prepare("UPDATE requests SET status = 'Need Revision' WHERE id = ?");
        $stmt->execute([$requestId]);
        
        $message = 'Preview link added successfully';
        $messageType = 'success';
    }
}

// Handle approval
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve'])) {
    $requestId = $_POST['request_id'];
    $stmt = $pdo->prepare("UPDATE requests SET status = 'Approved' WHERE id = ?");
    $stmt->execute([$requestId]);
    $message = 'Request approved';
    $messageType = 'success';
}

// Fetch all tokens with customer names
$stmt = $pdo->query("SELECT id, token_plain, customer_name, created_at, last_used FROM tokens ORDER BY created_at DESC");
$tokens = $stmt->fetchAll();

// Fetch all requests with token info
$stmt = $pdo->query("
    SELECT r.*, t.id as token_id, t.customer_name, res.result_file, res.preview_link
    FROM requests r 
    JOIN tokens t ON r.token_id = t.id 
    LEFT JOIN results res ON r.id = res.request_id 
    ORDER BY r.created_at DESC
");
$requests = $stmt->fetchAll();

// Statistik
$totalTokens = count($tokens);
$totalRequests = count($requests);
$pendingRequests = 0;
$completedRequests = 0;

foreach ($requests as $request) {
    if ($request['status'] === 'Pending') {
        $pendingRequests++;
    } elseif ($request['status'] === 'Approved') {
        $completedRequests++;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Jasa Joki</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#6366f1',
                        secondary: '#8b5cf6',
                        accent: '#06b6d4',
                        dark: '#1e293b'
                    },
                    backgroundImage: {
                        'gradient-primary': 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
                        'gradient-secondary': 'linear-gradient(135deg, #06b6d4 0%, #0ea5e9 100%)',
                        'gradient-accent': 'linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%)'
                    }
                    }
            }
        }
    </script>
    <style>
        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        .animate-pulse-slow {
            animation: pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.8; }
        }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-50 to-gray-100 min-h-screen">
    <!-- Header -->
    <header class="bg-gradient-primary text-white shadow-lg">
        <div class="container mx-auto px-4 py-6">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="flex items-center mb-4 md:mb-0">
                    <div class="bg-white p-2 rounded-lg mr-4">
                        <i class="fas fa-crown text-primary text-2xl"></i>
                    </div>
                    <div>
                        <h1 class="text-2xl font-bold">Jasa Joki Admin</h1>
                        <p class="text-indigo-200">Professional Task Management Dashboard</p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="text-right">
                        <p class="font-semibold">Admin Panel</p>
                        <p class="text-indigo-200 text-sm"><?= date('l, F j, Y') ?></p>
                    </div>
                    <a href="../logout.php" class="bg-white text-primary hover:bg-gray-100 px-4 py-2 rounded-lg font-medium flex items-center transition duration-300">
                        <i class="fas fa-sign-out-alt mr-2"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="container mx-auto px-4 py-8">
        <!-- Notification -->
        <?php if ($message): ?>
            <div class="mb-8 rounded-xl shadow-lg <?= $messageType === 'success' ? 'bg-gradient-primary text-white' : 'bg-red-100 text-red-800' ?> p-4">
                <div class="flex items-center">
                    <i class="fas <?= $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle' ?> text-xl mr-3"></i>
                    <span><?= htmlspecialchars($message) ?></span>
                </div>
            </div>
        <?php endif; ?>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div class="bg-white rounded-2xl shadow-lg p-6 card-hover transition-all duration-300 border-l-4 border-primary">
                <div class="flex justify-between items-center">
                    <div>
                        <p class="text-gray-500 text-sm">Total Tokens</p>
                        <p class="text-3xl font-bold text-gray-800"><?= $totalTokens ?></p>
                    </div>
                    <div class="bg-primary bg-opacity-10 p-3 rounded-full">
                        <i class="fas fa-key text-primary text-2xl"></i>
                    </div>
                </div>
                <div class="mt-4">
                    <div class="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div class="h-full bg-primary rounded-full" style="width: <?= min(100, $totalTokens * 10) ?>%"></div>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-2xl shadow-lg p-6 card-hover transition-all duration-300 border-l-4 border-secondary">
                <div class="flex justify-between items-center">
                    <div>
                        <p class="text-gray-500 text-sm">Total Requests</p>
                        <p class="text-3xl font-bold text-gray-800"><?= $totalRequests ?></p>
                    </div>
                    <div class="bg-secondary bg-opacity-10 p-3 rounded-full">
                        <i class="fas fa-tasks text-secondary text-2xl"></i>
                    </div>
                </div>
                <div class="mt-4">
                    <div class="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div class="h-full bg-secondary rounded-full" style="width: <?= $totalRequests > 0 ? 100 : 0 ?>%"></div>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-2xl shadow-lg p-6 card-hover transition-all duration-300 border-l-4 border-accent">
                <div class="flex justify-between items-center">
                    <div>
                        <p class="text-gray-500 text-sm">Pending Requests</p>
                        <p class="text-3xl font-bold text-gray-800"><?= $pendingRequests ?></p>
                    </div>
                    <div class="bg-accent bg-opacity-10 p-3 rounded-full">
                        <i class="fas fa-clock text-accent text-2xl"></i>
                    </div>
                </div>
                <div class="mt-4">
                    <div class="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div class="h-full bg-accent rounded-full" style="width: <?= $totalRequests > 0 ? ($pendingRequests/$totalRequests)*100 : 0 ?>%"></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Token Management Section -->
            <div class="lg:col-span-2">
                <div class="bg-white rounded-2xl shadow-lg overflow-hidden mb-8">
                    <div class="bg-gradient-primary p-5">
                        <h2 class="text-xl font-bold text-white flex items-center">
                            <i class="fas fa-key mr-3"></i> Token Management
                        </h2>
                    </div>
                    
                    <div class="p-6">
                        <form method="POST" class="mb-6 bg-gradient-to-r from-gray-50 to-gray-100 p-5 rounded-xl border border-gray-200">
                            <div class="mb-4">
                                <label for="customer_name" class="block text-gray-700 mb-2 font-medium">
                                    <i class="fas fa-user mr-2 text-primary"></i> Customer Name (Optional)
                                </label>
                                <input 
                                    type="text" 
                                    id="customer_name" 
                                    name="customer_name" 
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition duration-300"
                                    placeholder="Enter customer name"
                                >
                            </div>
                            <button 
                                type="submit" 
                                name="generate_token"
                                class="bg-gradient-primary text-white py-3 px-6 rounded-lg hover:opacity-90 transition duration-300 font-medium flex items-center"
                            >
                                <i class="fas fa-plus-circle mr-2"></i> Generate New Token
                            </button>
                        </form>
                        
                        <h3 class="text-lg font-semibold mb-4 flex items-center">
                            <i class="fas fa-list mr-2 text-primary"></i> Active Tokens
                        </h3>
                        <?php if (empty($tokens)): ?>
                            <div class="text-center py-10 bg-gray-50 rounded-xl">
                                <i class="fas fa-key text-gray-300 text-5xl mb-4"></i>
                                <p class="text-gray-500">No tokens have been generated yet.</p>
                            </div>
                        <?php else: ?>
                            <div class="overflow-x-auto rounded-xl border border-gray-200">
                                <table class="min-w-full divide-y divide-gray-200">
                                    <thead class="bg-gray-50">
                                        <tr>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Customer</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Token</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Created</th>
                                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody class="bg-white divide-y divide-gray-200">
                                        <?php foreach ($tokens as $token): ?>
                                            <tr class="hover:bg-gray-50 transition duration-150">
                                                <td class="px-6 py-4 whitespace-nowrap">
                                                    <div class="flex items-center">
                                                        <div class="bg-gray-200 border-2 border-dashed rounded-xl w-10 h-10 mr-3"></div>
                                                        <div>
                                                            <div class="text-sm font-medium text-gray-900"><?= htmlspecialchars($token['customer_name'] ?? 'Unnamed') ?></div>
                                                            <div class="text-sm text-gray-500">#<?= $token['id'] ?></div>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="px-6 py-4">
                                                    <div class="flex items-center">
                                                        <span class="font-mono text-sm bg-gray-100 px-3 py-1 rounded-lg">
                                                            <?= htmlspecialchars(substr($token['token_plain'], 0, 15)) ?>...
                                                        </span>
                                                        <button 
                                                            onclick="copyToClipboard('<?= htmlspecialchars($token['token_plain']) ?>')" 
                                                            class="ml-2 text-primary hover:text-indigo-700 transition duration-200"
                                                            title="Copy token"
                                                        >
                                                            <i class="fas fa-copy"></i>
                                                        </button>
                                                    </div>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                                    <?= date('M j, Y', strtotime($token['created_at'])) ?>
                                                    <div class="text-xs"><?= $token['last_used'] ? 'Used: ' . date('H:i', strtotime($token['last_used'])) : 'Never used' ?></div>
                                                </td>
                                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                                    <form method="POST" class="inline">
                                                        <input type="hidden" name="token_id" value="<?= $token['id'] ?>">
                                                        <button 
                                                            type="submit" 
                                                            name="delete_token"
                                                            class="text-red-500 hover:text-red-700 transition duration-200"
                                                            onclick="return confirm('Are you sure you want to delete this token?')"
                                                            title="Delete token"
                                                        >
                                                            <i class="fas fa-trash-alt"></i>
                                                        </button>
                                                    </form>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Request Management Section -->
            <div>
                <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                    <div class="bg-gradient-secondary p-5">
                        <h2 class="text-xl font-bold text-white flex items-center">
                            <i class="fas fa-tasks mr-3"></i> Request Management
                        </h2>
                    </div>
                    
                    <div class="p-6">
                        <h3 class="text-lg font-semibold mb-4 flex items-center">
                            <i class="fas fa-history mr-2 text-secondary"></i> Recent Requests
                        </h3>
                        <?php if (empty($requests)): ?>
                            <div class="text-center py-10 bg-gray-50 rounded-xl">
                                <i class="fas fa-inbox text-gray-300 text-5xl mb-4"></i>
                                <p class="text-gray-500">No requests have been submitted yet.</p>
                            </div>
                        <?php else: ?>
                            <div class="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                                <?php foreach (array_slice($requests, 0, 10) as $request): ?>
                                    <div class="border border-gray-200 rounded-xl p-4 hover:shadow-md transition duration-300">
                                        <div class="flex justify-between items-start">
                                            <div>
                                                <h4 class="font-medium text-gray-900"><?= htmlspecialchars($request['title']) ?></h4>
                                                <p class="text-sm text-gray-500 mt-1"><?= htmlspecialchars($request['customer_name'] ?? 'Unknown') ?></p>
                                            </div>
                                            <?php
                                            $statusClass = '';
                                            $statusIcon = '';
                                            switch ($request['status']) {
                                                case 'Pending': 
                                                    $statusClass = 'bg-yellow-100 text-yellow-800'; 
                                                    $statusIcon = 'fa-clock';
                                                    break;
                                                case 'In Progress': 
                                                    $statusClass = 'bg-blue-100 text-blue-800'; 
                                                    $statusIcon = 'fa-sync-alt';
                                                    break;
                                                case 'Need Revision': 
                                                    $statusClass = 'bg-purple-100 text-purple-800'; 
                                                    $statusIcon = 'fa-edit';
                                                    break;
                                                case 'Approved': 
                                                    $statusClass = 'bg-green-100 text-green-800'; 
                                                    $statusIcon = 'fa-check-circle';
                                                    break;
                                            }
                                            ?>
                                            <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full <?= $statusClass ?>">
                                                <i class="fas <?= $statusIcon ?> mr-1"></i> <?= htmlspecialchars($request['status']) ?>
                                            </span>
                                        </div>
                                        
                                        <div class="mt-3 flex flex-wrap gap-2">
                                            <?php if ($request['file_path']): ?>
                                                <a href="/<?= htmlspecialchars($request['file_path']) ?>" target="_blank" class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded flex items-center">
                                                    <i class="fas fa-file-download mr-1"></i> Task File
                                                </a>
                                            <?php endif; ?>
                                            
                                            <?php if ($request['result_file']): ?>
                                                <a href="/<?= htmlspecialchars($request['result_file']) ?>" target="_blank" class="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded flex items-center">
                                                    <i class="fas fa-file-download mr-1"></i> Result
                                                </a>
                                            <?php endif; ?>
                                            
                                            <?php if ($request['preview_link']): ?>
                                                <a href="<?= htmlspecialchars($request['preview_link']) ?>" target="_blank" class="text-xs bg-indigo-100 text-indigo-800 px-2 py-1 rounded flex items-center">
                                                    <i class="fas fa-external-link-alt mr-1"></i> Preview
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <div class="mt-3 pt-3 border-t border-gray-100">
                                            <form method="POST" class="flex flex-wrap gap-2">
                                                <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                                
                                                <select name="status" class="text-xs border rounded px-2 py-1">
                                                    <option value="Pending" <?= $request['status'] === 'Pending' ? 'selected' : '' ?>>Pending</option>
                                                    <option value="In Progress" <?= $request['status'] === 'In Progress' ? 'selected' : '' ?>>In Progress</option>
                                                    <option value="Need Revision" <?= $request['status'] === 'Need Revision' ? 'selected' : '' ?>>Need Revision</option>
                                                    <option value="Approved" <?= $request['status'] === 'Approved' ? 'selected' : '' ?>>Approved</option>
                                                </select>
                                                
                                                <button 
                                                    type="submit" 
                                                    name="update_status"
                                                    class="text-xs bg-gray-200 hover:bg-gray-300 text-gray-800 px-2 py-1 rounded"
                                                >
                                                    Update
                                                </button>
                                            </form>
                                        </div>
                                        
                                        <form method="POST" enctype="multipart/form-data" class="mt-2 flex flex-wrap gap-2">
                                            <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                            <input 
                                                type="file" 
                                                name="result_file" 
                                                accept=".zip,.docx,.pdf,.txt,.jpg,.png"
                                                class="text-xs flex-grow"
                                            >
                                            <input 
                                                type="url" 
                                                name="preview_link" 
                                                placeholder="Preview link"
                                                class="text-xs flex-grow border rounded px-2 py-1"
                                            >
                                            <button 
                                                type="submit" 
                                                name="upload_result"
                                                class="text-xs bg-purple-500 hover:bg-purple-600 text-white px-2 py-1 rounded"
                                            >
                                                Upload
                                            </button>
                                        </form>
                                        
                                        <?php if ($request['status'] === 'Need Revision' && ($request['result_file'] || $request['preview_link'])): ?>
                                            <form method="POST" class="mt-2">
                                                <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                                <button 
                                                    type="submit" 
                                                    name="approve"
                                                    class="text-xs bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded w-full"
                                                >
                                                    <i class="fas fa-check mr-1"></i> Approve Request
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-white border-t border-gray-200 mt-12 py-6">
        <div class="container mx-auto px-4 text-center text-gray-500 text-sm">
            <p>© <?= date('Y') ?> Jasa Joki Service. All rights reserved.</p>
            <p class="mt-1">Admin Dashboard v1.0</p>
        </div>
    </footer>

    <script>
        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                alert('Token copied to clipboard!');
            }).catch(err => {
                console.error('Failed to copy: ', err);
            });
        }
        
        // Add animation to stats cards on load
        document.addEventListener('DOMContentLoaded', function() {
            const cards = document.querySelectorAll('.card-hover');
            cards.forEach((card, index) => {
                setTimeout(() => {
                    card.classList.add('animate-pulse-slow');
                }, index * 200);
            });
        });
    </script>
</body>
</html>