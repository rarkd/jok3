<?php
require_once '../config/database.php';
require_once '../includes/auth.php';
requireCustomerAuth();

// Get customer's token ID
$tokenId = $_SESSION['token_id'];

// Handle form submission for new request
$message = '';
$messageType = 'success';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_request'])) {
    $title = $_POST['title'];
    $description = $_POST['description'];
    
    // Handle file upload
    $file_path = null;
    if (isset($_FILES['task_file']) && $_FILES['task_file']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = '../uploads/tasks/';
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $fileName = uniqid() . '_' . basename($_FILES['task_file']['name']);
        $targetPath = $uploadDir . $fileName;
        
        // Validate file size (max 50MB)
        if ($_FILES['task_file']['size'] > 50 * 1024 * 1024) {
            $message = 'File too large. Maximum size is 50MB.';
            $messageType = 'error';
        } else {
            // Move uploaded file
            if (move_uploaded_file($_FILES['task_file']['tmp_name'], $targetPath)) {
                $file_path = 'uploads/tasks/' . $fileName;
            } else {
                $message = 'Failed to upload file.';
                $messageType = 'error';
            }
        }
    }
    
    if (!$message) {
        // Insert request into database
        $stmt = $pdo->prepare("INSERT INTO requests (token_id, title, description, file_path) VALUES (?, ?, ?, ?)");
        $stmt->execute([$tokenId, $title, $description, $file_path]);
        $message = 'Request submitted successfully!';
        $messageType = 'success';
    }
}

// Handle approval
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve'])) {
    $requestId = $_POST['request_id'];
    $stmt = $pdo->prepare("UPDATE requests SET status = 'Approved' WHERE id = ? AND token_id = ?");
    $stmt->execute([$requestId, $tokenId]);
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit();
}

// Handle request revision
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_revision'])) {
    $requestId = $_POST['request_id'];
    $stmt = $pdo->prepare("UPDATE requests SET status = 'Need Revision' WHERE id = ? AND token_id = ?");
    $stmt->execute([$requestId, $tokenId]);
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit();
}

// Fetch customer's requests
$stmt = $pdo->prepare("
    SELECT r.*, res.result_file, res.preview_link
    FROM requests r 
    LEFT JOIN results res ON r.id = res.request_id 
    WHERE r.token_id = ? 
    ORDER BY r.created_at DESC
");
$stmt->execute([$tokenId]);
$requests = $stmt->fetchAll();

// Get customer info
$stmt = $pdo->prepare("SELECT customer_name FROM tokens WHERE id = ?");
$stmt->execute([$tokenId]);
$customer = $stmt->fetch();
$customerName = $customer['customer_name'] ?? 'Customer';

// Calculate statistics
$totalRequests = count($requests);
$pendingRequests = 0;
$completedRequests = 0;
$inProgressRequests = 0;

foreach ($requests as $request) {
    switch ($request['status']) {
        case 'Pending':
            $pendingRequests++;
            break;
        case 'In Progress':
            $inProgressRequests++;
            break;
        case 'Approved':
            $completedRequests++;
            break;
        case 'Need Revision':
            $inProgressRequests++;
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Dashboard - Jasa Joki</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#3b82f6',
                        secondary: '#8b5cf6',
                        accent: '#06b6d4',
                        dark: '#1e293b'
                    },
                    backgroundImage: {
                        'gradient-primary': 'linear-gradient(135deg, #3b82f6 0%, #6366f1 100%)',
                        'gradient-secondary': 'linear-gradient(135deg, #8b5cf6 0%, #ec4899 100%)',
                        'gradient-accent': 'linear-gradient(135deg, #06b6d4 0%, #0ea5e9 100%)'
                    }
                }
            }
        }
    </script>
    <style>
        .card-hover:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
        }
        .animate-pulse-slow {
            animation: pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.8; }
        }
        .progress-bar {
            height: 8px;
            border-radius: 4px;
            overflow: hidden;
        }
        .progress-fill {
            height: 100%;
            border-radius: 4px;
            transition: width 0.5s ease-in-out;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-50 to-gray-100 min-h-screen">
    <!-- Header -->
    <header class="bg-gradient-primary text-white shadow-lg">
        <div class="container mx-auto px-4 py-6">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <div class="flex items-center mb-4 md:mb-0">
                    <div class="bg-white p-2 rounded-lg mr-4">
                        <i class="fas fa-user-circle text-primary text-2xl"></i>
                    </div>
                    <div>
                        <h1 class="text-2xl font-bold">Welcome, <?= htmlspecialchars($customerName) ?>!</h1>
                        <p class="text-blue-200">Customer Dashboard</p>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="text-right">
                        <p class="font-semibold">Your Requests</p>
                        <p class="text-blue-200 text-sm"><?= date('l, F j, Y') ?></p>
                    </div>
                    <a href="../logout.php" class="bg-white text-primary hover:bg-gray-100 px-4 py-2 rounded-lg font-medium flex items-center transition duration-300">
                        <i class="fas fa-sign-out-alt mr-2"></i> Logout
                    </a>
                </div>
            </div>
        </div>
    </header>

    <div class="container mx-auto px-4 py-8">
        <!-- Notification -->
        <?php if ($message): ?>
            <div class="mb-8 rounded-xl shadow-lg <?= $messageType === 'success' ? 'bg-gradient-primary text-white' : 'bg-red-100 text-red-800' ?> p-4">
                <div class="flex items-center">
                    <i class="fas <?= $messageType === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle' ?> text-xl mr-3"></i>
                    <span><?= htmlspecialchars($message) ?></span>
                </div>
            </div>
        <?php endif; ?>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div class="bg-white rounded-2xl shadow-lg p-6 card-hover transition-all duration-300 border-l-4 border-primary">
                <div class="flex justify-between items-center">
                    <div>
                        <p class="text-gray-500 text-sm">Total Requests</p>
                        <p class="text-3xl font-bold text-gray-800"><?= $totalRequests ?></p>
                    </div>
                    <div class="bg-primary bg-opacity-10 p-3 rounded-full">
                        <i class="fas fa-tasks text-primary text-2xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-2xl shadow-lg p-6 card-hover transition-all duration-300 border-l-4 border-accent">
                <div class="flex justify-between items-center">
                    <div>
                        <p class="text-gray-500 text-sm">Pending</p>
                        <p class="text-3xl font-bold text-gray-800"><?= $pendingRequests ?></p>
                    </div>
                    <div class="bg-accent bg-opacity-10 p-3 rounded-full">
                        <i class="fas fa-clock text-accent text-2xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-2xl shadow-lg p-6 card-hover transition-all duration-300 border-l-4 border-secondary">
                <div class="flex justify-between items-center">
                    <div>
                        <p class="text-gray-500 text-sm">In Progress</p>
                        <p class="text-3xl font-bold text-gray-800"><?= $inProgressRequests ?></p>
                    </div>
                    <div class="bg-secondary bg-opacity-10 p-3 rounded-full">
                        <i class="fas fa-sync-alt text-secondary text-2xl"></i>
                    </div>
                </div>
            </div>
            
            <div class="bg-white rounded-2xl shadow-lg p-6 card-hover transition-all duration-300 border-l-4 border-green-500">
                <div class="flex justify-between items-center">
                    <div>
                        <p class="text-gray-500 text-sm">Completed</p>
                        <p class="text-3xl font-bold text-gray-800"><?= $completedRequests ?></p>
                    </div>
                    <div class="bg-green-100 p-3 rounded-full">
                        <i class="fas fa-check-circle text-green-500 text-2xl"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Create Request Form -->
            <div class="lg:col-span-2">
                <div class="bg-white rounded-2xl shadow-lg overflow-hidden mb-8">
                    <div class="bg-gradient-primary p-5">
                        <h2 class="text-xl font-bold text-white flex items-center">
                            <i class="fas fa-plus-circle mr-3"></i> Create New Request
                        </h2>
                    </div>
                    
                    <div class="p-6">
                        <form method="POST" enctype="multipart/form-data">
                            <div class="mb-4">
                                <label for="title" class="block text-gray-700 mb-2 font-medium">
                                    <i class="fas fa-heading mr-2 text-primary"></i> Title
                                </label>
                                <input 
                                    type="text" 
                                    id="title" 
                                    name="title" 
                                    required 
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition duration-300"
                                    placeholder="Enter task title"
                                >
                            </div>
                            <div class="mb-4">
                                <label for="description" class="block text-gray-700 mb-2 font-medium">
                                    <i class="fas fa-align-left mr-2 text-primary"></i> Description
                                </label>
                                <textarea 
                                    id="description" 
                                    name="description" 
                                    rows="4" 
                                    required 
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition duration-300"
                                    placeholder="Describe your task in detail..."
                                ></textarea>
                            </div>
                            <div class="mb-6">
                                <label for="task_file" class="block text-gray-700 mb-2 font-medium">
                                    <i class="fas fa-file-upload mr-2 text-primary"></i> Upload Task File
                                </label>
                                <input 
                                    type="file" 
                                    id="task_file" 
                                    name="task_file" 
                                    accept=".zip,.docx,.pdf,.txt,.jpg,.png"
                                    class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition duration-300"
                                >
                                <p class="text-gray-500 text-sm mt-2">
                                    <i class="fas fa-info-circle mr-1"></i> Max file size: 50MB. Supported formats: ZIP, DOCX, PDF, TXT, JPG, PNG
                                </p>
                            </div>
                            <button 
                                type="submit" 
                                name="create_request"
                                class="bg-gradient-primary text-white py-3 px-6 rounded-lg hover:opacity-90 transition duration-300 font-medium flex items-center w-full justify-center"
                            >
                                <i class="fas fa-paper-plane mr-2"></i> Submit Request
                            </button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Requests List -->
            <div>
                <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                    <div class="bg-gradient-secondary p-5">
                        <h2 class="text-xl font-bold text-white flex items-center">
                            <i class="fas fa-history mr-3"></i> My Requests
                        </h2>
                    </div>
                    
                    <div class="p-6">
                        <?php if (empty($requests)): ?>
                            <div class="text-center py-10 bg-gray-50 rounded-xl">
                                <i class="fas fa-inbox text-gray-300 text-5xl mb-4"></i>
                                <p class="text-gray-500">You haven't submitted any requests yet.</p>
                                <p class="text-gray-400 text-sm mt-2">Submit your first request using the form!</p>
                            </div>
                        <?php else: ?>
                            <div class="space-y-4 max-h-[600px] overflow-y-auto pr-2">
                                <?php foreach ($requests as $request): ?>
                                    <div class="border border-gray-200 rounded-xl p-4 hover:shadow-md transition duration-300">
                                        <div class="flex justify-between items-start">
                                            <div>
                                                <h4 class="font-medium text-gray-900"><?= htmlspecialchars($request['title']) ?></h4>
                                                <p class="text-sm text-gray-500 mt-1 truncate"><?= htmlspecialchars(substr($request['description'], 0, 50)) ?><?= strlen($request['description']) > 50 ? '...' : '' ?></p>
                                            </div>
                                            <?php
                                            $statusClass = '';
                                            $statusIcon = '';
                                            switch ($request['status']) {
                                                case 'Pending': 
                                                    $statusClass = 'bg-yellow-100 text-yellow-800'; 
                                                    $statusIcon = 'fa-clock';
                                                    break;
                                                case 'In Progress': 
                                                    $statusClass = 'bg-blue-100 text-blue-800'; 
                                                    $statusIcon = 'fa-sync-alt';
                                                    break;
                                                case 'Need Revision': 
                                                    $statusClass = 'bg-purple-100 text-purple-800'; 
                                                    $statusIcon = 'fa-edit';
                                                    break;
                                                case 'Approved': 
                                                    $statusClass = 'bg-green-100 text-green-800'; 
                                                    $statusIcon = 'fa-check-circle';
                                                    break;
                                            }
                                            ?>
                                            <span class="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full <?= $statusClass ?>">
                                                <i class="fas <?= $statusIcon ?> mr-1"></i> <?= htmlspecialchars($request['status']) ?>
                                            </span>
                                        </div>
                                        
                                        <div class="mt-3 text-xs text-gray-500">
                                            <i class="far fa-calendar-alt mr-1"></i> <?= date('M j, Y', strtotime($request['created_at'])) ?>
                                        </div>
                                        
                                        <div class="mt-3 flex flex-wrap gap-2">
                                            <?php if ($request['file_path']): ?>
                                                <a href="/<?= htmlspecialchars($request['file_path']) ?>" target="_blank" class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded flex items-center">
                                                    <i class="fas fa-file-download mr-1"></i> Task File
                                                </a>
                                            <?php endif; ?>
                                            
                                            <?php if ($request['result_file']): ?>
                                                <a href="/<?= htmlspecialchars($request['result_file']) ?>" target="_blank" class="text-xs bg-purple-100 text-purple-800 px-2 py-1 rounded flex items-center">
                                                    <i class="fas fa-file-download mr-1"></i> Result
                                                </a>
                                            <?php endif; ?>
                                            
                                            <?php if ($request['preview_link']): ?>
                                                <a href="<?= htmlspecialchars($request['preview_link']) ?>" target="_blank" class="text-xs bg-indigo-100 text-indigo-800 px-2 py-1 rounded flex items-center">
                                                    <i class="fas fa-external-link-alt mr-1"></i> Preview
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <div class="mt-3 pt-3 border-t border-gray-100">
                                            <?php if ($request['result_file'] || $request['preview_link']): ?>
                                                <?php if ($request['status'] === 'Need Revision'): ?>
                                                    <div class="flex flex-wrap gap-2">
                                                        <form method="POST" class="flex-grow">
                                                            <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                                            <button type="submit" name="approve" class="text-xs bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded w-full">
                                                                <i class="fas fa-thumbs-up mr-1"></i> Approve
                                                            </button>
                                                        </form>
                                                        <form method="POST" class="flex-grow">
                                                            <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                                            <button type="submit" name="request_revision" class="text-xs bg-orange-500 hover:bg-orange-600 text-white px-3 py-1 rounded w-full">
                                                                <i class="fas fa-redo mr-1"></i> Request Revision
                                                            </button>
                                                        </form>
                                                    </div>
                                                <?php elseif ($request['status'] !== 'Approved'): ?>
                                                    <div class="text-center py-2 bg-blue-50 rounded">
                                                        <span class="text-blue-800 text-xs">
                                                            <i class="fas fa-cog animate-spin mr-1"></i> Processing your request
                                                        </span>
                                                    </div>
                                                <?php else: ?>
                                                    <div class="text-center py-2 bg-green-50 rounded">
                                                        <span class="text-green-800 text-xs">
                                                            <i class="fas fa-check-circle mr-1"></i> Completed
                                                        </span>
                                                    </div>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <div class="text-center py-2 bg-gray-50 rounded">
                                                    <span class="text-gray-500 text-xs">
                                                        <i class="fas fa-hourglass-half mr-1"></i> Awaiting results
                                                    </span>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="bg-white border-t border-gray-200 mt-12 py-6">
        <div class="container mx-auto px-4 text-center text-gray-500 text-sm">
            <p>© <?= date('Y') ?> Jasa Joki Service. All rights reserved.</p>
            <p class="mt-1">Customer Dashboard v1.0</p>
        </div>
    </footer>
</body>
</html>