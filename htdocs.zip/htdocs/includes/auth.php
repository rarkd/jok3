<?php
session_start();

function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']);
}

function isCustomerLoggedIn() {
    return isset($_SESSION['token_id']);
}

function requireAdminAuth() {
    if (!isAdminLoggedIn()) {
        header('Location: /login_admin.php');
        exit();
    }
}

function requireCustomerAuth() {
    if (!isCustomerLoggedIn()) {
        header('Location: /login_customer.php');
        exit();
    }
}

function generateToken() {
    return bin2hex(random_bytes(32));
}

function hashToken($token) {
    return password_hash($token, PASSWORD_DEFAULT);
}

function verifyToken($token, $hash) {
    return password_verify($token, $hash);
}
?>